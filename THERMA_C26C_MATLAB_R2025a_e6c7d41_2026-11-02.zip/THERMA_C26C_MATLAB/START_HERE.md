# THERMA C2.6C — start here (Windows / MATLAB R2025a)

This folder already contains the complete pinned THERMA work source and the verified
C2.6 solar replay packet in its required location. No Git, Python or Docker is needed.

## Run

1. In Windows Explorer, right-click the downloaded ZIP and choose **Extract All**.
   Extract to a short, writable local folder, for example `C:\THERMA_C26C`.
   Do not run files inside the ZIP or from a read-only/network folder.
2. Open **MATLAB R2025a** with **Simulink** available on your university licence.
   Use normal MATLAB with Java enabled. Simscape and the original FMU runtime are
   not required for this reduced C2 replay.
3. In MATLAB, browse to the extracted `THERMA_C26C_MATLAB` folder containing
   `run_verification.m` and this file. Open **run_verification.m** and click **Run**.
   If MATLAB asks, choose **Change Folder**. Alternatively, with this folder as
   Current Folder, type:

   ```matlab
   run_verification
   ```

4. Wait for package integrity checks, the MATLAB tests, model generation and the
   21-day simulated replay (7-day warm-up + 14-day evaluation). Simulated days are
   not real elapsed days. Leave MATLAB running; no measured runtime is promised.
5. At completion the Command Window prints the replay report and test-log locations.
   Do not edit the original packet or generated result files.

No files need to be moved. The packet is already at:

```text
outputs/boptest/THERMA_C26_solar_replay/packet/replay.json
```

## What is included / how the Simulink model is supplied

- Full THERMA source, MATLAB scripts, tests, configuration, documentation and prior
  verification evidence from the source commit recorded in PACKAGE_PROVENANCE.json.
- The verified solar replay packet, seven-surface/source data, reference evaluation
  subset and extraction reports, byte-for-byte from the published transfer archive.
- The exact existing C1/C2 **Simulink model-builder scripts** and their helper blocks.
  The verified source branch has no committed pre-generated `.slx` models. The runner
  automatically builds and saves the real `.slx` model in MATLAB before simulation;
  no prebuilt model or external download is required. No SLX was fabricated in cloud.
- This launcher, PACKAGE_PROVENANCE.json and a per-file PACKAGE_SHA256SUMS manifest.

C1/C2 thermal equations and physical parameters are unchanged. The cloud checks do
not establish MATLAB execution of this package: that is the run you are about to do.
Solar-resolved THERMA performance and improvement over the baseline remain unmeasured.

## Outputs to preserve

New folders are created for each run; the input packet is not overwritten.

- `outputs/boptest/verification_c26c/<new-folder>/`: test-result CSV/MAT and Command
  Window diary; replay_report_location.txt points to successful replay results.
- `outputs/boptest/replays/<new-folder>/`: `evaluation.csv`,
  `comparison_metadata.json`, `replay_run.json`, `trajectory.csv`, `simulation.mat`
  and the generated C2 `.slx` model.
- Model/test builders may also create fresh folders under `outputs/boptest/simulink_c1`
  and `outputs/boptest/simulink_c2`.

For later cloud comparison, supply the three replay files **evaluation.csv**,
**comparison_metadata.json** and **replay_run.json** from the same new replay folder.
Keep simulation.mat and the full logs locally as well. Successful execution is not
by itself BOPTEST validation: glazing/exterior/moist-air differences remain.

## If it stops

- **Checksum mismatch / missing file:** extract a fresh copy and do not edit the
  scripts, packet or documentation before running. Keep outputs separate from inputs.
- **Simulink unavailable / licence error:** enable your university Simulink licence.
- **A MATLAB test fails or is incomplete:** replay stops. Preserve the test CSV/MAT,
  diary and package_failure.json. Do not bypass tests or change physical parameters.
- **Replay fails:** preserve nested diagnostics in replay_run.json, the diary and
  package_failure.json. Send those reports back rather than only the final assertion.
- **Access denied / long Windows path:** extract into a shorter writable local path.
- **Source model already open:** save any unrelated work, close previously generated
  THERMA models, then retry from a fresh extraction if needed.

Full engineering background: docs/C26_SOLAR_BENCHMARK.md. The older transfer README
inside the replay folder describes the previous two-ZIP workflow; this package is
already assembled and supersedes those relocation steps.
