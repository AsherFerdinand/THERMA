% THERMA C2.6C: open this script in MATLAB R2025a and click Run.
% No Git, Python, Docker or manual dataset relocation is required.
% Existing C1/C2 equations and the solar packet are used unchanged.
thermaPackageRoot = fileparts(mfilename('fullpath'));
thermaReplayReport = run_therma_c26c_package(thermaPackageRoot);

function reportFile = run_therma_c26c_package(root)
assert(usejava('jvm'),'THERMA:PackageJava', ...
    'Start normal MATLAB with Java enabled; do not use -nojvm.');
assert(~isempty(ver('Simulink')) && license('test','Simulink'), ...
    'THERMA:PackageSimulink','MATLAB with an available Simulink licence is required.');
if ~strcmp(version('-release'),'2025a')
    warning('THERMA:PackageRelease', ...
        'This package targets MATLAB/Simulink R2025a; current release is %s.',version('-release'));
end
previousPath = path;
pathCleanup = onCleanup(@() path(previousPath));
addpath(fullfile(root,'scripts','matlab','boptest'));
fprintf('THERMA package: %s\nChecking all packaged file hashes...\n',root);
manifest = splitlines(string(fileread(fullfile(root,'PACKAGE_SHA256SUMS'))));
checked = 0;
for j = 1:numel(manifest)
    entry = char(manifest(j));
    if isempty(strtrim(entry)), continue; end
    parts = regexp(entry,'^([0-9a-f]{64})  (.+)$','tokens','once');
    assert(~isempty(parts),'THERMA:PackageManifest','Malformed checksum entry %d.',j);
    relative = parts{2};
    assert(~startsWith(relative,'/') && ~contains(relative,'\') && ...
        ~contains(relative,':') && ~any(strcmp(strsplit(relative,'/'),'..')), ...
        'THERMA:PackageManifest','Unsafe checksum path.');
    file = fullfile(root,strrep(relative,'/',filesep));
    assert(isfile(file),'THERMA:PackageMissing','Missing packaged file: %s',relative);
    assert(strcmp(boptest_file_sha256(file),parts{1}), ...
        'THERMA:PackageHash','File changed or extraction damaged: %s',relative);
    checked = checked+1;
end
assert(checked>0,'THERMA:PackageManifest','Empty package checksum manifest.');
fprintf('Verified %d packaged files.\n',checked);
packet = fullfile(root,'outputs','boptest','THERMA_C26_solar_replay','packet');
load_boptest_replay(fullfile(packet,'replay.json'));
parent = fullfile(root,'outputs','boptest','verification_c26c');
if ~isfolder(parent), mkdir(parent); end
session = tempname(parent); mkdir(session);
diary(fullfile(session,'MATLAB_command_window.txt'));
diaryCleanup = onCleanup(@() diary('off'));
fprintf('Test/log directory: %s\n',session);
try
    results = runtests(fullfile(root,'tests','matlab'),'IncludeSubfolders',true);
    save(fullfile(session,'matlab_test_results.mat'),'results');
    testTable = table({results.Name}',[results.Passed]',[results.Failed]', ...
        [results.Incomplete]',[results.Duration]', ...
        'VariableNames',{'Name','Passed','Failed','Incomplete','Duration_s'});
    writetable(testTable,fullfile(session,'matlab_test_results.csv'));
    disp(testTable);
    assert(~isempty(results),'THERMA:PackageNoTests','No MATLAB tests were discovered.');
    assertSuccess(results);
    assert(all([results.Passed]) && ~any([results.Incomplete]), ...
        'THERMA:PackageTests','All MATLAB tests must pass before replay.');
    fprintf('Tests passed. Building and running the unchanged C2 model with solar v2 inputs.\n');
    reportFile = run_boptest_solar_batch(packet);
    fprintf('\nC2.6C replay completed; this is still a partial reference comparison.\n');
    fprintf('Replay report: %s\n',reportFile);
    fprintf('Preserve evaluation.csv, comparison_metadata.json, replay_run.json and simulation.mat\n');
    fprintf('from the report directory for the later comparison. Test logs: %s\n',session);
    fid = fopen(fullfile(session,'replay_report_location.txt'),'w');
    assert(fid>=0,'THERMA:PackageLog','Could not save replay report location.');
    fileCleanup = onCleanup(@() fclose(fid));
    fprintf(fid,'%s\n',reportFile);
catch problem
    write_boptest_json(fullfile(session,'package_failure.json'), ...
        boptest_exception_diagnostic(problem));
    fprintf(2,'Stopped. Preserve logs in %s and any replay_run.json.\n',session);
    rethrow(problem);
end
end
