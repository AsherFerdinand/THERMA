# C2.5C engineering analysis

Scope: actual_supplied_MATLAB_replay_exports.
Exploratory analysis only; no BOPTEST validation or calibrated accuracy claim.

Supplied MATLAB report: executed_partial_not_validated (25.1.0.2943329 (R2025a)).
Codex did not independently execute MATLAB.

Evaluation: 58008 samples over 14 days; sample spacing 0.24683–30 s.
Warm-up is excluded. Original absolute model seconds are preserved.

| Signed delivered heat | Minimum W | Negative samples | Reconstructed negative energy J |
|---|---:|---:|---:|
| delivered_heating_power | -27.8247 | 392 | -234537 |
| delivered_heating_convective_power | 3.95217 | 0 | 0 |
| delivered_heating_radiative_power | -32.3846 | 580 | -374001 |

No negative values were clamped. The original source sign audit is in metrics.json.
Stored-energy change: 4.94742e+07 J.
Maximum instantaneous power residual: 2.81943e-11 W.
Integral energy closure: {'status': 'blocked', 'missing': 'net_external_power not exported in standard evaluation.csv', 'reason': 'Heating, internal gains and ventilation omit exterior/window boundary fluxes; do not sum an incomplete system boundary.'}.
Heating component accounting: {'maximum_discrepancy_W': 1.0686562745831907e-11, 'arithmetic_budget_W': np.float64(5.820766091346741e-11), 'consistent_at_roundoff': True}.
Sensible infiltration formula check: {'status': 'checked_against_recorded_reduced_assumptions', 'conductance_W_K': 21.729599999999998, 'maximum_formula_discrepancy_W': 2.2737367544323206e-11, 'note': 'Positive into zone; this is sensible infiltration, not reference moist-air enthalpy validation.'}.

Reference comparison: available_exploratory_only.
Indoor air temperature: MAE 2.34053 K, RMSE 2.8055 K, sampled max error 7.4341 K, bias -2.3352 K.
Bias is THERMA minus BOPTEST. Continuous candidate temperature is aligned to the native reference timestamps, without extrapolation.
Errors include omitted forcing, initialization and reduced physics; they are not solver errors alone.

Known limitations:

- six absorbed interior solar powers
- complete initialized reference state vector
- Reduced C2 moist-air/surface/glazing physics differs from reference.
- Prescribed radiator heat removes equipment feedback; heating is not predicted.
- Solar forcing is omitted and initial states are provisional; do not attribute all temperature errors to solver accuracy.
- Temperature metrics use native reference timestamps; sample spacing limits peak resolution. No acceptance threshold is inferred.
- Power integrals use declared reconstruction, not unknown continuous waveforms.
- Small instantaneous residual alone does not prove total energy closure or reference validity.
- No values clamped, calibrated, smoothed or overwritten.

Recommended next work:

- Inspect matched input/sign diagnostics and first exploratory comparison before C2.6.
- Obtain absorbed solar and consistent full initial-state/warm-up policy.
- Then prioritize glazing/solar, exterior exchange and radiative environment; preserve independent verification.
- Export total external net power to permit a full sampled integral energy check.

Additional actual-data diagnostics:

- The original full source trajectory reproduces both heating components at every actual MATLAB CSV timestamp to within 5.01e-12 W. Raw union-grid power differences are output-reconstruction artifacts, not evidence of a source sign or driver mismatch.
- First/second evaluation-week bias: -3.15352 / -1.51691 K. This trend cannot uniquely identify initialization versus missing forcing/physics.
- Supplemental derivations: input_limit_audit.json and temperature_details.json; original CSV/JSON inputs remain unchanged.
