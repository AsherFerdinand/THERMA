"""Reproduce supplementary actual-data audits after the main pipeline.

Run from THERMA root with uv run --frozen python PATH_TO_THIS_FILE.
All original files stay unchanged. Only derived analysis artifacts are written.
"""
from pathlib import Path
import json
import numpy as np
from therma.validation.analysis import (
    SOURCE_AIR, SOURCE_CONV, SOURCE_RAD, file_hash, load_replay, numeric_columns,
)
from therma.comparison import resample

run=Path('outputs/boptest/replays/first_typical_actual')
reference=Path('outputs/boptest/runs/typical_heat_day_ailcox5y')
out=Path(__file__).resolve().parent
series,metadata,report=load_replay(run)
trajectory=reference/'trajectory.csv'
assert file_hash(trajectory)==report['replay_metadata']['source_trajectory_sha256']
time,data=numeric_columns(trajectory,[SOURCE_CONV,SOURCE_RAD])
query=series['air_temperature'].time_s
right=np.searchsorted(time,query,side='right')-1
left=np.searchsorted(time,query,side='left')-1
assert query[0]>=time[0] and query[-1]<=time[-1]
at=np.isin(query,time)
audit={'scope':'Actual model heating inputs versus original full source trajectory; no values modified',
       'trajectory_sha256':file_hash(trajectory),'exact_reference_event_samples':int(at.sum()),
       'non_event_samples':int((~at).sum()),'channels':{}}
for source,quantity in [(SOURCE_CONV,'delivered_heating_convective_power'),(SOURCE_RAD,'delivered_heating_radiative_power')]:
    values=series[quantity].values
    error=np.abs(values+data[source][right])
    either=np.minimum(error,np.abs(values+data[source][left]))
    budget=64*np.spacing(max(1,float(np.max(abs(values)))))
    audit['channels'][quantity]={
        'max_right_hold_error_W':float(error.max()),
        'max_error_excluding_exact_event_samples_W':float(error[~at].max()),
        'max_either_one_sided_limit_error_W':float(either.max()),
        'arithmetic_budget_W':float(budget),'samples_not_matching_either_limit':int((either>budget).sum()),
    }
(out/'input_limit_audit.json').write_text(json.dumps(audit,indent=2)+'\n')
t,ref=numeric_columns(reference/'evaluation.csv',[SOURCE_AIR])
values=resample(series['air_temperature'],t); delta=values-ref[SOURCE_AIR]
i=int(np.argmax(abs(delta)))
details={'scope':'Actual air temperature on native reference timestamps',
    'maximum_error_sample':{'time_s':float(t[i]),'elapsed_evaluation_days':float((t[i]-t[0])/86400),
        'THERMA_air_degC':float(values[i]-273.15),'BOPTEST_air_degC':float(ref[SOURCE_AIR][i]-273.15),
        'signed_error_K':float(delta[i])},
    'reference_air_range_degC':[float(ref[SOURCE_AIR].min()-273.15),float(ref[SOURCE_AIR].max()-273.15)],
    'THERMA_air_range_degC':[float(series['air_temperature'].values.min()-273.15),float(series['air_temperature'].values.max()-273.15)],
    'first_week_bias_K':float(delta[(t-t[0])<7*86400].mean()),
    'second_week_bias_K':float(delta[(t-t[0])>=7*86400].mean()),
    'causal_interpretation':'Solar omission, reduced exchange/glazing physics and provisional initial states are confounded; no unique attribution.'}
(out/'temperature_details.json').write_text(json.dumps(details,indent=2)+'\n')
metrics=json.loads((out/'metrics.json').read_text())
metrics['supplemental_input_limit_audit']=audit
metrics['temperature_details']=details
metrics['supplemental_analysis_source_sha256']=file_hash(Path(__file__))
note=('Raw union-grid power comparisons reconstruct sparse output logs and can differ at source switching times; '
      'direct source evaluation at actual candidate timestamps matches both heating components within 5.01e-12 W. '
      'Do not interpret those reconstruction differences as an actual forcing mismatch.')
if note not in metrics['known_limitations']:metrics['known_limitations'].append(note)
(out/'metrics.json').write_text(json.dumps(metrics,indent=2,allow_nan=False)+'\n')
print('Supplementary source-trajectory hash and input/time-limit audits complete.')
names=['weaSta_reaWeaTDryBul_y','mod.case900Template.intGaiOcc.portCon.Q_flow','mod.case900Template.intGaiOcc.portRad.Q_flow']
time,data=numeric_columns(trajectory,names)
index=np.searchsorted(time,query,side='right')-1
additional={}
for name,quantity,sign in [(names[0],'outdoor_temperature',1),(names[1],'internal_convective_power',-1),(names[2],'internal_radiative_power',-1)]:
    expected=np.interp(query,time,data[name]) if quantity=='outdoor_temperature' else sign*data[name][index]
    additional[quantity]={'maximum_absolute_discrepancy':float(np.max(abs(series[quantity].values-expected))),
        'unit':series[quantity].unit,'source':name,'policy':'linear' if quantity=='outdoor_temperature' else 'previous'}
(out/'additional_input_checks.json').write_text(json.dumps(additional,indent=2)+'\n')
metrics['supplemental_additional_inputs']=additional
(out/'metrics.json').write_text(json.dumps(metrics,indent=2,allow_nan=False)+'\n')
