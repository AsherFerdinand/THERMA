# Actual first typical replay analysis

These results use the three original MATLAB attachments, unchanged, and the
hash-matched original BOPTEST typical reference. MATLAB was not rerun.

metrics.json and engineering_summary.md contain the actual exploratory results.
plots/ contains all six figure pairs (PNG and PDF).
input_limit_audit.json checks the full original source forcing at actual candidate
timestamps; temperature_details.json includes the worst sample and week-wise bias.
attachment_integrity.json records unchanged uploaded-file hashes.

Main reproduction from THERMA root:
uv run --frozen --with matplotlib==3.10.8 python -m therma.validation.analysis analyze --run-dir outputs/boptest/replays/first_typical_actual --reference-run outputs/boptest/runs/typical_heat_day_ailcox5y --output NEW_OUTPUT_DIRECTORY

The optional supplementary audit script expects the same source/run paths and
metrics.json in its directory. It writes derived diagnostics only.

This results bundle excludes the three raw MATLAB input files, runtime environments,
model files, original reference CSVs and plotting caches. It is exploratory analysis,
not BOPTEST validation. Full integrated energy closure remains blocked by missing
net external power in the exported CSV. No calibration or clamping was performed.
