# THERMA C2.6 solar-resolved partial replay

Use updated work-branch source (GitHub Code -> Download ZIP). Extract this folder
under its outputs/boptest/ directory. From THERMA root in MATLAB eventually run:

    addpath('scripts/matlab/boptest');
    results=runtests('tests/matlab'); assertSuccess(results);
    run_boptest_solar_batch('outputs/boptest/THERMA_C26_solar_replay/packet');

See docs/C26_SOLAR_BENCHMARK.md in work for full instructions.
Codex executed only the original BOPTEST FMU, not MATLAB or the solar THERMA replay.
The reference/ subset is for future comparison, not reference regeneration: its
original manifest also describes the full trajectory not included here. All included
original files retain their bytes/hashes. Seven solar shares are preserved; glazing
is never redistributed. No original MATLAB uploads, FMU/runtime or models included.
Verify every included payload using SHA256SUMS; the outer ZIP checksum is recorded
in work docs/C26_ARTIFACTS.json and replay-transfer C26_SHA256SUMS.
