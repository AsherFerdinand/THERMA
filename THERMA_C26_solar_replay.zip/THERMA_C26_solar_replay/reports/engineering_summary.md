# Actual solar reference extraction (not THERMA validation)

The original FMU was executed without overrides on its original 30 s grid. Common baseline channels match exactly. All seven source solar allocations are preserved; only six opaque powers enter the new replay packet.

The existing no-solar MAE 2.34053 K and bias -2.33520 K remain exploratory. Missing solar is a plausible contributor, not a quantified explanation. Initial opaque temperatures already match 293.15 K. Glazing, exterior exchange and moist-air differences remain. No solar-resolved MATLAB run or improvement measurement exists yet.

{
  "status": "passed",
  "surface_order": [
    "south",
    "west",
    "north",
    "east",
    "floor",
    "roof",
    "glazing"
  ],
  "max_distribution_residual_W": 2.255973186038318e-13,
  "max_direct_sum_residual_W": 9.094947017729282e-13,
  "max_diffuse_sum_residual_W": 2.2737367544323206e-13,
  "max_solar_sum_residual_W": 1.3642420526593924e-12,
  "direct_weights": [
    0.030720000000000004,
    0.05184000000000001,
    0.06912,
    0.05184000000000001,
    0.6,
    0.15360000000000001,
    0.04288000000000001
  ],
  "diffuse_weights": [
    0.05549132947976879,
    0.09364161849710984,
    0.12485549132947978,
    0.09364161849710984,
    0.2774566473988439,
    0.2774566473988439,
    0.07745664739884395
  ],
  "gain_weights": [
    0.05594405594405596,
    0.09440559440559443,
    0.1258741258741259,
    0.09440559440559443,
    0.27972027972027974,
    0.27972027972027974,
    0.06993006993006994
  ],
  "evaluation_solar_hold_energy_J": {
    "south": 10669178.975869458,
    "west": 18004239.52177971,
    "north": 24005652.695706278,
    "east": 18004239.52177971,
    "floor": 96621797.10566969,
    "roof": 53345894.87934729,
    "glazing": 14892395.653817788
  },
  "samples": 60481,
  "interpretation": "30 s held reconstruction, not exact continuous FMU energy"
}
