# THERMA C4.2B - measured-data inspection update

Extract INTO your existing THERMA_C35_MATLAB folder. Base MATLAB R2025a with
JVM is sufficient; no Simulink, Git, Python or WSL is needed for this inspection.
Native execution of this new script has NOT been performed in Codex.
This is an inspection package, not a building model or validation result.

1. Download the six ORIGINAL CSVs from DOWNLOAD_FLEXLAB_FILES.md using your browser.
   Preserve the listed folders/filenames below data/reference_building/raw/flexlab/.
   Or use an already-extracted official FLEXLAB source folder as the argument.
   Raw data are NOT included: their redistribution licence is unresolved.
2. In MATLAB select the existing THERMA folder, then run:

```matlab
cd('C:\PATH\TO\THERMA_C35_MATLAB')
output = run_c42b_flexlab_inspection;
% Alternative with an official dataset folder elsewhere:
% output = run_c42b_flexlab_inspection('C:\PATH\TO\FLEXLAB-ASHRAE140');
```

The script checks every source SHA-256 before reading, selects23June2021
00:00-12:00 PST (fixedUTC-08, no DST),721 genuine minute rows per file,
and displays channels, missing counts and full-source sampling intervals/gaps.
It writes two measured-data PNGs and inspection_summary.json under a NEW
outputs/c4/c42b/ folder. Original CSVs and all previous results are unchanged.
Missing files, changed bytes or incomplete selected data cause an explicit error;
no interpolation or synthetic data are generated. Repeated runs use separate folders.

Read docs/C42B_VALIDATION_FEASIBILITY.md for the CONDITIONAL recommendation:
separate main Cell3B test-cell envelope benchmark, not a residential house or an
independently validated heating system. Construction conflicts and unknown fabric
initial states remain. No C4.3/model/physics changes are included.

The two PNGs under docs/results/c42b are actual-measurement Python previews,
not evidence of native MATLAB execution. No original measurement arrays are included.

Source commit: cf8a6b73e2be305e3669f645b2960f92af9fa01a
Upstream commit: 265312ec3843c97d5a24b7d5671ee2891f326af6
