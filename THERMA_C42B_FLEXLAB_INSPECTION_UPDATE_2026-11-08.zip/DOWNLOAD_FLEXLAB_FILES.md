# Download original FLEXLAB files

Use each official immutable URL below. Save as the destination shown, preserving spaces.
Do not save the GitHub HTML preview. The MATLAB entry verifies the SHA-256.

- [Direct Validation Data/Air temperature.csv](https://raw.githubusercontent.com/LBNL-ETA/FLEXLAB-ASHRAE140/265312ec3843c97d5a24b7d5671ee2891f326af6/Direct%20Validation%20Data/Air%20temperature.csv)
  Save to `data/reference_building/raw/flexlab/Direct Validation Data/Air temperature.csv`
  SHA256: `4acf940bd14959eaf5928d707ea23069477f440c736c6dbd7d96c5a1c5e852ea`

- [Input Data/Weather data.csv](https://raw.githubusercontent.com/LBNL-ETA/FLEXLAB-ASHRAE140/265312ec3843c97d5a24b7d5671ee2891f326af6/Input%20Data/Weather%20data.csv)
  Save to `data/reference_building/raw/flexlab/Input Data/Weather data.csv`
  SHA256: `bf568d2ee4e59e8d19c8248ae533174c9a2b88abda6797bff381f4e6b7c6e9d0`

- [Input Data/Internal heat gain rate.csv](https://raw.githubusercontent.com/LBNL-ETA/FLEXLAB-ASHRAE140/265312ec3843c97d5a24b7d5671ee2891f326af6/Input%20Data/Internal%20heat%20gain%20rate.csv)
  Save to `data/reference_building/raw/flexlab/Input Data/Internal heat gain rate.csv`
  SHA256: `b2406f14eedab4bae634370c33618ddbbe250d73401c55b54c137aa2545d713e`

- [Input Data/Duct blaster.csv](https://raw.githubusercontent.com/LBNL-ETA/FLEXLAB-ASHRAE140/265312ec3843c97d5a24b7d5671ee2891f326af6/Input%20Data/Duct%20blaster.csv)
  Save to `data/reference_building/raw/flexlab/Input Data/Duct blaster.csv`
  SHA256: `938737f6f923c519bc22cfd272d830aad715aac0f2d66a8997031bf31d8146ed`

- [Direct Validation Data/Fan coil units.csv](https://raw.githubusercontent.com/LBNL-ETA/FLEXLAB-ASHRAE140/265312ec3843c97d5a24b7d5671ee2891f326af6/Direct%20Validation%20Data/Fan%20coil%20units.csv)
  Save to `data/reference_building/raw/flexlab/Direct Validation Data/Fan coil units.csv`
  SHA256: `f6ec373a516c85e98214bf286387d1c09dc8ab82f891f2dbbaf58f59a1504794`

- [Input Data/Exterior surface temperature.csv](https://raw.githubusercontent.com/LBNL-ETA/FLEXLAB-ASHRAE140/265312ec3843c97d5a24b7d5671ee2891f326af6/Input%20Data/Exterior%20surface%20temperature.csv)
  Save to `data/reference_building/raw/flexlab/Input Data/Exterior surface temperature.csv`
  SHA256: `7b511a998c12ef627593c64071fd32b98bba4499ee8047726bfb8a261776553b`

