THERMA C3.7 PREPARATION ONLY - NOT READY FOR THE HEATING RUN

Extract into your EXISTING THERMA_C35_MATLAB folder, retaining all old files.
Do not extract into an empty replacement project. No old source is overwritten.
No Python, Git or WSL is needed to inspect these files in MATLAB R2025a.

The20m2 corner-room configuration and single-run entry point are prepared.
Manufacturer websites were inaccessible in Codex (HTTP403). No radiator output,
UA, flow, heating-time or energy result has been fabricated. Before the full run,
provide the manufacturer datasheet to Codex so the rating can be reviewed,
archived with SHA256, and configs/c37/radiator_rating.json completed correctly.
The current entry point deliberately stops with THERMA:C37RatingMissing.
Do not just set the status flag or invent missing numbers to bypass that error.

Room-only static test (MATLAB R2025a, no simulation):
  cd('C:\YOUR_PATH\THERMA_C35_MATLAB')
  result = runtests(fullfile('tests','matlab','test_therma_c37.m'));
  assertSuccess(result);

After the manufacturer evidence/configuration has been completed, the intended
single24h simulation command is:
  run_c37_residential_heating
It will produce two plots and actual energy/temperature metrics under outputs/c3/c37.
No parameter sweep or new heating component is introduced.

214 Python tests and MATLAB static checks passed in cloud. MATLAB execution
was unavailable; even the new static MATLAB unit test remains unexecuted there.
Read docs/C37_RESIDENTIAL_HEATING.md for assumptions, limitations and the blocker.
Source commit: afaa57b8604f3af6e30a228cebe33bd2e86010d0
