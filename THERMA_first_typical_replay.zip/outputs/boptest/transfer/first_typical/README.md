# First partial typical-heating replay

Extract this ZIP into your existing THERMA repository root. It supplies replay
inputs, normalized reference evaluation data and original manifest/signal provenance.
It does not include the FMU, native libraries or full original 61-column datasets.
No Git or Python is required on the university computer.

In MATLAB, set Current Folder to THERMA, then run:

```matlab
addpath(fullfile(pwd,'scripts','matlab','boptest'));
packet = fullfile(pwd,'outputs','boptest','replay_inputs','first_typical','replay.json');
assumptions = fullfile(pwd,'configs','references','c2_reduced_assumptions.json');
[info,data] = load_boptest_replay(packet);
reportFile = run_boptest_zone_replay(packet,assumptions,'AllowPartial',true);
disp(reportFile);
```

Save/close any existing generated C2 model first. The replay runs seven warm-up
and fourteen evaluation days; 60,481 forcing samples, 30-second source spacing.
Temperature is piecewise linear; power inputs are held. Missing absorbed solar
is explicitly omitted and uniform declared initial temperatures are provisional.
This is an exploratory comparison, not a complete BOPTEST validation.

Return evaluation.csv, comparison_metadata.json and replay_run.json from the
printed outputs/boptest/replays/<unique>/ folder. On failure, return replay_run.json
and the full MATLAB error. No need to transfer large simulation.mat or .slx files.
