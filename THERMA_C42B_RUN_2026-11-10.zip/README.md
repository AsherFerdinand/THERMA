# THERMA C42B lightweight run

Fresh extraction only; no old THERMA folder needed. Read MATLAB_QUICKSTART.md.
In MATLAB R2025a: result = run_therma_experiment("C42B", "C:\FLEXLAB_DATA");
Only base MATLAB with JVM is required; no Simulink/Git/Python/WSL.
Six external original CSVs are NOT bundled. Missing-data errors give official URLs.
Optional explicit download: addpath tools/matlab scripts/matlab/boptest;
acquire_therma_inputs('C:\FLEXLAB_DATA','download',pwd);
Download mode needs Internet; existing local files work offline.
Native execution of this new wrapper remains pending. No simulation is performed.
Return the generated THERMA_RESULTS_C42B.zip; keep originals until an archive receipt.
Audit the OLD folder before deletion:
audit_therma_local_storage('C:\OLD\THERMA_C35_MATLAB');
The audit never deletes files or approves deletion.
