function tests = test_boptest_event_export
% Synthetic IO tests only; not real BOPTEST/MATLAB benchmark evidence.
tests=functiontests(localfunctions);
end
function setupOnce(testCase)
root=fileparts(fileparts(fileparts(mfilename('fullpath'))));
testCase.TestData.oldPath=path;
addpath(fullfile(root,'scripts','matlab','boptest'));
end
function teardownOnce(testCase)
path(testCase.TestData.oldPath);
end
function logs = fixture(n)
t=floor((0:n-1)'/2);
logs=struct('time_s',t,'stored_thermal_energy',sin(t),'net_external_power',cos(t), ...
    'stored_energy_derivative',cos(t),'prescribed_inputs',zeros(n,11), ...
    'power_balance_residual',ones(n,1)*eps);
logs.prescribed_inputs(:,2)=pi;
end
function testSmallPrecisionDuplicateTimesAndBounds(testCase)
folder=tempname; mkdir(folder); cleanup=onCleanup(@() rmdir(folder,'s'));
logs=fixture(12); logs.stored_thermal_energy(3)=realmin;
logs.net_external_power(4)=-realmax;
file=fullfile(folder,'energy_events.csv');
info=boptest_export_energy_events(file,logs,'StagingDirectory',folder, ...
    'ChunkRows',3,'TimeOriginSeconds',100,'StartSeconds',101,'EndSeconds',104);
actual=readmatrix(file,'NumHeaderLines',1); indices=3:10;
expected=[logs.time_s(indices)+100 logs.stored_thermal_energy(indices) ...
    logs.net_external_power(indices) logs.stored_energy_derivative(indices) ...
    sum(logs.prescribed_inputs(indices,2:11),2) logs.power_balance_residual(indices)];
verifyEqual(testCase,actual,expected);
verifyEqual(testCase,info.status,'verified'); verifyEqual(testCase,info.verification.row_count,8);
verifyEqual(testCase,info.sha256,boptest_file_sha256(file));
verifyEqual(testCase,sum(diff(actual(:,1))==0),4);
end
function testLargeChunkedExport(testCase)
folder=tempname; mkdir(folder); cleanup=onCleanup(@() rmdir(folder,'s'));
file=fullfile(folder,'large.csv'); logs=fixture(50000);
info=boptest_export_energy_events(file,logs,'StagingDirectory',folder,'ChunkRows',257);
verifyEqual(testCase,info.verification.row_count,50000);
verifyEqual(testCase,info.sha256,boptest_file_sha256(file));
verified=boptest_verify_energy_csv(file,50000); verifyEqual(testCase,verified.last_time_s,24999);
end
function testInvalidOutputDiagnosticAndOriginalCause(testCase)
folder=tempname; mkdir(folder); cleanup=onCleanup(@() rmdir(folder,'s'));
file=fullfile(folder,'missing','energy_events.csv');
try
    boptest_export_energy_events(file,fixture(4),'StagingDirectory',folder);
    verifyFail(testCase,'Expected failure.');
catch problem
    verifyEqual(testCase,problem.identifier,'THERMA:EventExport');
    verifyEqual(testCase,problem.cause{1}.identifier,'THERMA:EventDirectory');
    verifyTrue(testCase,contains(problem.message,file));
    verifyTrue(testCase,contains(problem.message,'estimated_numeric_bytes'));
    failures=dir(fullfile(folder,'*.event_export_failure.json'));
    verifyNumElements(testCase,failures,1);
    diagnostic=jsondecode(fileread(fullfile(folder,failures(1).name)));
    verifyEqual(testCase,diagnostic.target_file,file);
    verifyEqual(testCase,diagnostic.output_directory,fileparts(file));
    verifyFalse(testCase,diagnostic.directory_exists);
    verifyEqual(testCase,diagnostic.original_exception.identifier,'THERMA:EventDirectory');
end
verifyFalse(testCase,isfile(file));
end
function testNeverOverwriteVerifiedTarget(testCase)
folder=tempname; mkdir(folder); cleanup=onCleanup(@() rmdir(folder,'s'));
file=fullfile(folder,'energy.csv');
boptest_export_energy_events(file,fixture(8),'StagingDirectory',folder);
original=boptest_file_sha256(file);
verifyError(testCase,@() boptest_export_energy_events(file,fixture(9), ...
    'StagingDirectory',folder),'THERMA:EventExport');
verifyEqual(testCase,boptest_file_sha256(file),original);
end
function testInterruptedAndMisorderedCSVRejected(testCase)
folder=tempname; mkdir(folder); cleanup=onCleanup(@() rmdir(folder,'s'));
file=fullfile(folder,'energy.csv');
boptest_export_energy_events(file,fixture(8),'StagingDirectory',folder);
raw=fileread(file); fid=fopen(file,'wb'); fwrite(fid,uint8(raw(1:end-5)),'uint8'); fclose(fid);
verifyError(testCase,@() boptest_verify_energy_csv(file,8),'THERMA:EventCSVTruncated');
logs=fixture(8); logs.time_s(5)=-1;
verifyError(testCase,@() boptest_export_energy_events(fullfile(folder,'bad.csv'),logs, ...
    'StagingDirectory',folder),'THERMA:EventExport');
verifyFalse(testCase,isfile(fullfile(folder,'bad.csv')));
end
function testUNCContextWithoutAssumingNetworkAvailability(testCase)
% Path classification is testable offline; this does not claim actual UNC IO success.
info=boptest_event_export_context('\\server\share\Eigene Dateien\energy.csv',100,120,false);
verifyTrue(testCase,info.is_unc_path);
verifyEqual(testCase,info.estimated_numeric_bytes,100*6*8);
verifyTrue(testCase,isfield(info,'available_disk_space_bytes'));
root=fileparts(fileparts(fileparts(mfilename('fullpath'))));
if ispc && startsWith(root,'\\')
    % A real UNC write is tested only when the actual test installation is on UNC.
    parent=fullfile(root,'outputs','boptest');
    if ~isfolder(parent), mkdir(parent); end
    folder=tempname(parent); mkdir(folder); cleanup=onCleanup(@() rmdir(folder,'s'));
    exported=boptest_export_energy_events(fullfile(folder,'network.csv'),fixture(5000));
    verifyEqual(testCase,exported.status,'verified');
    verifyEqual(testCase,exported.verification.row_count,5000);
end
end
function testNormalEOFAndAdditionalRows(testCase)
% Write independently of the exporter so normal EOF verification is isolated.
folder=tempname; mkdir(folder); cleanup=onCleanup(@() rmdir(folder,'s'));
file=fullfile(folder,'valid.csv');
header='time_s,stored_thermal_energy,net_external_power,stored_energy_derivative,prescribed_power,power_balance_residual';
fid=fopen(file,'wb'); fprintf(fid,'%s\n0,1,2,3,4,0\n0,2,3,4,5,0\n',header); fclose(fid);
info=boptest_verify_energy_csv(file,2);
verifyEqual(testCase,info.row_count,2); verifyEqual(testCase,info.first_time_s,0);
verifyEqual(testCase,info.last_time_s,0);
verifyEqual(testCase,info.sha256,boptest_file_sha256(file));
fid=fopen(file,'ab'); fprintf(fid,'1,2,3,4,5,0\n'); fclose(fid);
verifyError(testCase,@() boptest_verify_energy_csv(file,2),'THERMA:EventCSVRows');
end
function testMissingColumnsAndNonfiniteValuesRejected(testCase)
folder=tempname; mkdir(folder); cleanup=onCleanup(@() rmdir(folder,'s'));
file=fullfile(folder,'bad.csv');
header='time_s,stored_thermal_energy,net_external_power,stored_energy_derivative,prescribed_power,power_balance_residual';
fid=fopen(file,'wb'); fprintf(fid,'%s\n0,1,2,3,4\n',header); fclose(fid);
verifyError(testCase,@() boptest_verify_energy_csv(file,1),'THERMA:EventCSVColumns');
fid=fopen(file,'wb'); fprintf(fid,'%s\n0,1,NaN,3,4,0\n',header); fclose(fid);
verifyError(testCase,@() boptest_verify_energy_csv(file,1),'THERMA:EventCSVValues');
end
function testCleanupIsIdempotentAndCannotCloseReusedHandle(testCase)
folder=tempname; mkdir(folder); cleanup=onCleanup(@() rmdir(folder,'s'));
resources=BoptestEventExportResources();
resources.FileId=fopen(fullfile(folder,'first.tmp'),'wb');
resources.StagingFile=fullfile(folder,'first.tmp');
guard=onCleanup(@() resources.cleanup());
verifyEqual(testCase,resources.closeFile(),0);
% A new fopen can reuse the numeric ID. Cleanup must not close that new file.
fid=fopen(fullfile(folder,'second.tmp'),'wb');
otherCleanup=onCleanup(@() fclose(fid));
clear guard;
verifyEqual(testCase,fwrite(fid,uint8('still open'),'uint8'),10);
resources.cleanup(); resources.cleanup();
verifyTrue(testCase,isfile(resources.StagingFile)); % Failed-stage retention is unchanged.
clear otherCleanup; % Close the independent file before the folder cleanup can run.
end
function testFailureCleanupPreservesOriginalCauseAndClosesHandles(testCase)
folder=tempname; mkdir(folder); cleanup=onCleanup(@() rmdir(folder,'s'));
before=sort(fopen('all')); lastwarn('');
try
    boptest_export_energy_events(fullfile(folder,'missing','events.csv'),fixture(8), ...
        'StagingDirectory',folder);
    verifyFail(testCase,'Expected invalid-directory failure.');
catch problem
    verifyEqual(testCase,problem.identifier,'THERMA:EventExport');
    verifyEqual(testCase,problem.cause{1}.identifier,'THERMA:EventDirectory');
end
drawnow;
[message,~]=lastwarn;
verifyEmpty(testCase,message);
verifyEqual(testCase,sort(fopen('all')),before);
end
function testExactChunkBoundaryAndSplitFinalRecord(testCase)
folder=tempname; mkdir(folder); cleanup=onCleanup(@() rmdir(folder,'s'));
header=sprintf('time_s,stored_thermal_energy,net_external_power,stored_energy_derivative,prescribed_power,power_balance_residual\n');
line=sprintf('0,1,2,3,4,0\n'); boundary=1024*1024;
padding=mod(boundary-numel(header),numel(line));
first=[repmat('0',1,padding) line];
tailRows=(boundary-numel(header)-numel(first))/numel(line);
text=[header first repmat(line,1,tailRows)];
verifyEqual(testCase,numel(text),boundary);
file=fullfile(folder,'exact_chunk.csv');
fid=fopen(file,'wb'); fwrite(fid,uint8(text),'uint8'); fclose(fid);
info=boptest_verify_energy_csv(file,tailRows+1);
verifyEqual(testCase,info.file_bytes,boundary);
verifyEqual(testCase,info.sha256,boptest_file_sha256(file));
% One leading zero shifts the final LF into the next chunk without changing values.
text=[header '0' first repmat(line,1,tailRows)];
fid=fopen(file,'wb'); fwrite(fid,uint8(text),'uint8'); fclose(fid);
info=boptest_verify_energy_csv(file,tailRows+1);
verifyEqual(testCase,info.file_bytes,boundary+1);
verifyEqual(testCase,info.row_count,tailRows+1);
end
function testMinimalReaderProbeUsesObservedStatuses(testCase)
folder=tempname; mkdir(folder); cleanup=onCleanup(@() rmdir(folder,'s'));
file=reproduce_boptest_csv_reader(folder); observed=jsondecode(fileread(file));
verifyEqual(testCase,observed.snapshot_verification.row_count,2);
verifyEqual(testCase,observed.snapshot_verification.sha256,observed.csv_sha256);
verifyNotEmpty(testCase,observed.fgetl); verifyNotEmpty(testCase,observed.fread);
% No assertion about whether this MATLAB/OS reports -4, -1, zero or another diagnostic.
end
function testAllMalformedRecordClassesStayRejected(testCase)
folder=tempname; mkdir(folder); cleanup=onCleanup(@() rmdir(folder,'s'));
file=fullfile(folder,'invalid.csv');
header=sprintf('time_s,stored_thermal_energy,net_external_power,stored_energy_derivative,prescribed_power,power_balance_residual\n');
records={sprintf('0,1,2,3,4,0,7\n'),sprintf('0,1,Inf,3,4,0\n'), ...
    sprintf('1,1,2,3,4,0\n0,1,2,3,4,0\n'),sprintf('0,1,2,3,4,0')};
expected={'THERMA:EventCSVColumns','THERMA:EventCSVValues','THERMA:EventCSVOrder','THERMA:EventCSVTruncated'};
counts=[1 1 2 1];
for j=1:numel(records)
    fid=fopen(file,'wb'); fwrite(fid,uint8([header records{j}]),'uint8'); fclose(fid);
    verifyError(testCase,@() boptest_verify_energy_csv(file,counts(j)),expected{j});
end
end
function testWindowsCRLFHeaderSemanticsAndDigest(testCase)
folder=tempname; mkdir(folder); cleanup=onCleanup(@() rmdir(folder,'s'));
file=fullfile(folder,'crlf.csv');
header='time_s,stored_thermal_energy,net_external_power,stored_energy_derivative,prescribed_power,power_balance_residual';
fid=fopen(file,'wb');
fprintf(fid,'%s\r\n0,1,2,3,4,0\r\n0,2,3,4,5,0\r\n',header); fclose(fid);
info=boptest_verify_energy_csv(file,2);
verifyEqual(testCase,info.row_count,2); verifyEqual(testCase,info.first_time_s,0);
verifyEqual(testCase,info.sha256,boptest_file_sha256(file));
end
